# Proyecto Frontend - Topicos Selectos De Ingenieria de Software 

## Integrantes y responsabilidades 💻🛜

| Nombre completo                        | Matrícula | Contribución                  |
|----------------------------------------|-----------|-------------------------------|
| JAVIER ABNER RODRIGUEZ FRIAS           | 180276    | Desarrollo en React / Vistas |
| ADÁN OSWALDO FRAIRE LÓPEZ              | 202765    | Diseño de vistas en Figma y desarrollo de vistas   |
| HUGO ABISAÍ REYES TREJO                | 215201    | Integración de endpoints      |
| NATHALIE MENDOZA TORRES                | 192966    | Apoyo en diseño de vistas     |

## Tecnologías utilizadas

- React
- HTML5 / CSS3
- JavaScript
- Figma (diseño previo)
