import React, { useEffect, useState } from 'react';
import './Home.css';
import { Link, useNavigate } from 'react-router-dom';

const SERVICES = [
  { to: '/jmas-servicio',           img: '/assets/jmas.png',            alt: 'JMAS', label: 'Pagar JMAS' },
  { to: '/servicios?service=gasnn', img: '/assets/GN.png',              alt: 'Gas Natural', label: 'Pagar Gas Natural' },
  { to: '/predial',                 img: '/assets/catastro.png',        alt: 'Catastro', label: 'Pagar Predial' },
  { to: '/revalidacion',            img: '/assets/pagos_chihuahua.png', alt: 'Pagos Chihuahua', label: 'Revalidación' }
];

export default function Home() {
  const [username, setUsername] = useState('Usuario');
  const [showServices, setShowServices] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const storedName = localStorage.getItem('username');
    if (storedName) {
      setUsername(storedName);
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('username');
    navigate('/login');
  };

  return (
    <div className="home-wrapper">
      <nav className="navbar">
        <div className="navbar-left">
          <Link className="nav-item active" to="/home">Inicio</Link>
          <div
            className="dropdown nav-item"
            onMouseEnter={() => setShowServices(true)}
            onMouseLeave={() => setShowServices(false)}
          >
            Servicios
            {showServices && (
              <ul className="dropdown-content">
                {SERVICES.map((s) => (
                  <li key={s.to}><Link to={s.to}>{s.alt}</Link></li>
                ))}
              </ul>
            )}
          </div>
          <Link className="nav-item" to="/generar-codigo">Generar código</Link>
          <img src="/assets/logo-tss.png" alt="Logo" className="nav-logo-textsize" />
        </div>

        <div
          className="dropdown nav-item user-dropdown-wrapper"
          onMouseEnter={() => setShowUserMenu(true)}
          onMouseLeave={() => setShowUserMenu(false)}
        >
          <img src="/assets/user.png" alt="User" className="user-icon-small" />
          {showUserMenu && (
            <ul className="dropdown-content dropdown-right">
              <li><button onClick={handleLogout} className="dropdown-btn">Cerrar Sesión</button></li>
            </ul>
          )}
        </div>
      </nav>

      <section className="main-section">
        <div className="promo-left">
          <h2 className="main-title">
            Hola <span className="brand-highlight">{username}!</span><br />
            Todo listo<br />
            Para realizar<br />
            <span className="brand-highlight">Tu primer pago</span>
          </h2>
        </div>

        <div className="service-buttons-column">
          {SERVICES.map((s) => (
            <div className="service-row" key={s.to}>
              <Link to={s.to} className="service-button">
                <img src={s.img} alt={s.alt} className="service-logo" />
              </Link>
              <div className="service-label-wrapper">
                <span className="service-label">{s.label}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      <div className="footer-yellow" />
    </div>
  );
}
