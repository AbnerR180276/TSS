import React from 'react';
import { Link } from 'react-router-dom';     // 👈 Nuevo
import './FormStyles.css';

export default function PromoSection() {
  return (
    <div className="promo-section">
      <div className="promo-content">
        <h2 className="promo-heading">
          Realiza tus pagos<br />
          de forma más cómoda<br />
          <span className="brand-highlight">con TSSPayments</span>
        </h2>

        <p>Puedes realizar pagos en:</p>

        {/* Badges -> ahora son enlaces */}
        <div className="store-badges">
          {/* JMAS Agua */}
            <img src="/assets/jmas.png" alt="JMAS" />


          {/* Gas Natural (usa la vista genérica de servicios) */}

            <img src="/assets/GN.png" alt="Gas Natural" />


          {/* Impuesto Predial */}

            <img src="/assets/catastro.png" alt="Catastro" />


          {/* Revalidación Vehicular */}

            <img src="/assets/pagos_chihuahua.png" alt="Pagos Chihuahua" />
        </div>

        <div className="phones-section">
          <img
            src="/assets/celulares.png"
            alt="App TSSPayments"
            className="phones-image"
          />
        </div>
      </div>
    </div>
  );
}