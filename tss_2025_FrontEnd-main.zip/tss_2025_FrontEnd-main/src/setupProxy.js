// src/setupProxy.js
const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {
  // Proxy JMAS endpoints
  app.use([
    '/prod/jmas',
    '/prod/jmas/*',
    '/prod/barcode/jmas',
    '/prod/barcode/jmas/*',
    '/prod/pago/jmas',
    '/prod/pago/jmas/*'
  ], createProxyMiddleware({
    target: 'https://nvyfmt7sgd.execute-api.us-west-2.amazonaws.com',
    changeOrigin: true,
    secure: true,
  }));

  // Proxy Predial endpoints
  app.use([
    '/prod/predial',
    '/prod/predial/*',
    '/prod/barcode/predial',
    '/prod/barcode/predial/*',
    '/prod/pago/predial',
    '/prod/pago/predial/*'
  ], createProxyMiddleware({
    target: 'https://2s19gmoi2l.execute-api.us-west-2.amazonaws.com',
    changeOrigin: true,
    secure: true,
  }));

  // Proxy Revalidación Vehicular endpoints
  app.use([
    '/prod/revalidacion',
    '/prod/revalidacion/*',
    '/prod/barcode/revalidacion',
    '/prod/barcode/revalidacion/*',
    '/prod/pago/revalidacion',
    '/prod/pago/revalidacion/*'
  ], createProxyMiddleware({
    target: 'https://lrjxs6izo0.execute-api.us-west-2.amazonaws.com',
    changeOrigin: true,
    secure: true,
  }));
};
