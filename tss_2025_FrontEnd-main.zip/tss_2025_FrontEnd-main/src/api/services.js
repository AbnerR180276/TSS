const JMAS_BASE_URL         = "https://nvyfmt7sgd.execute-api.us-west-2.amazonaws.com/prod/jmas";
const PREDIAL_BASE_URL      = "https://2s19gmoi2l.execute-api.us-west-2.amazonaws.com/prod/predial";
const REVALIDACION_BASE_URL = "https://lrjxs6izo0.execute-api.us-west-2.amazonaws.com/prod/revalidacion";

async function post(url, payload) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`Error ${res.status}: ${await res.text()}`);
  return res.json();
}

export const postJmas         = (data) => post(JMAS_BASE_URL, data);
export const postPredial      = (data) => post(PREDIAL_BASE_URL, data);
export const postRevalidacion = (data) => post(REVALIDACION_BASE_URL, data);

// Opcional: alias para código viejo
export const postJson = post;
