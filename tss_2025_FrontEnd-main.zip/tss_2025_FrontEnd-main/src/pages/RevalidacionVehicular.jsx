import React, { useState, useEffect } from 'react';
import { getRevalidacionData, postRevalidacion } from '../services/api';
import './Forms.css';
import { Link } from 'react-router-dom';

const SERVICES = [
  { to: '/jmas-servicio', img: '/assets/jmas.png', alt: 'JMAS', label: 'Pagar JMAS' },
  { to: '/servicios?service=gasnn', img: '/assets/GN.png', alt: 'Gas Natural', label: 'Pagar Gas Natural' },
  { to: '/predial', img: '/assets/catastro.png', alt: 'Catastro', label: 'Pagar Predial' },
  { to: '/revalidacion', img: '/assets/pagos_chihuahua.png', alt: 'Pagos Chihuahua', label: 'Revalidación' }
];

export default function RevalidacionPage() {
  const [vehiculo, setVehiculo] = useState({
    placa: '', propietario: '', modelo: '', marca: '', linea: '', serie: '', tipo: 'auto'
  });
  const [msg, setMsg] = useState('');
  const [registros, setRegistros] = useState([]);

  useEffect(() => {
    loadRegistros();
  }, []);

  const loadRegistros = async () => {
    try {
      const data = await getRevalidacionData();
      setRegistros(data);
    } catch (err) {
      console.error('Error al cargar registros Revalidación:', err);
      setMsg('Error al cargar registros de Revalidación.');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMsg('Enviando…');
    try {
      await postRevalidacion(vehiculo);
      setMsg('✓ Solicitud registrada');
      setVehiculo({ placa:'', propietario:'', modelo:'', marca:'', linea:'', serie:'', tipo:'auto' });
      await loadRegistros();
    } catch (err) {
      setMsg('Error: ' + err.message);
    }
  };

  return (
    <div className="jmas-page-wrapper">
      <nav className="navbar-forms">
        <div className="navbar-left">
          <Link className="nav-item active" to="/home">Inicio</Link>
          <div className="dropdown nav-item">
            Servicios
            <ul className="dropdown-content">
              {SERVICES.map((s) => (
                <li key={s.to}><Link to={s.to}>{s.alt}</Link></li>
              ))}
            </ul>
          </div>
          <Link className="nav-item" to="/generar-codigo">Generar código</Link>
        </div>

        <div className="navbar-right">
          <div className="user-menu">
            <img src="/assets/user.png" alt="User" className="user-icon" />
            <div className="user-dropdown">
              <button className="user-btn">Iniciar Sesión</button>
              <button className="user-btn">Cerrar Sesión</button>
            </div>
          </div>
          <img src="/assets/logo-tss.png" alt="Logo" className="nav-logo" />
        </div>
      </nav>

      <h2 className="jmas-title">Revalidación Vehicular</h2>

      <div className="jmas-content-wrapper">
        <div className="jmas-form-section">
          <form onSubmit={handleSubmit} className="jmas-form-layout">
            {["placa", "propietario", "modelo", "marca", "linea", "serie"].map((campo) => (
              <div key={campo} className="form-field-group">
                <label htmlFor={campo} className="form-label">{campo.charAt(0).toUpperCase() + campo.slice(1)}</label>
                <input
                  required
                  id={campo}
                  name={campo}
                  placeholder={campo.charAt(0).toUpperCase() + campo.slice(1)}
                  value={vehiculo[campo]}
                  onChange={(e) => setVehiculo({ ...vehiculo, [campo]: e.target.value })}
                  className="jmas-input"
                />
              </div>
            ))}

            <div className="form-field-group">
              <label htmlFor="tipo" className="form-label">Tipo</label>
              <select
                id="tipo"
                value={vehiculo.tipo}
                onChange={e => setVehiculo({ ...vehiculo, tipo: e.target.value })}
                className="jmas-input"
              >
                <option value="auto">Auto</option>
                <option value="moto">Moto</option>
                <option value="camion">Camión</option>
              </select>
            </div>

            <button type="submit" className="jmas-button jmas-submit-button">
              Registrar
            </button>
          </form>
          {msg && <p className="jmas-error-message">{msg}</p>}
        </div>

        <div className="jmas-services-section">
          <h3 className="jmas-subtitle">Solicitudes Registradas</h3>
          <div className="jmas-services-list">
            {registros.length > 0 ? (
              registros.map((r, i) => (
                <div key={i} className="jmas-service-item">
                  <h4 className="jmas-service-account">Placa: {r.placa}</h4>
                  <p className="jmas-service-detail">Propietario: {r.propietario}</p>
                  <p className="jmas-service-detail">Estado: {r.estatus}</p>
                  <p className="jmas-service-detail">Adeudo: ${r.adeudo_total?.toFixed(2)}</p>
                </div>
              ))
            ) : (
              <p className="jmas-error-message">No hay solicitudes registradas.</p>
            )}
          </div>
        </div>
      </div>

      <div className="footer-yellow" />
    </div>
  );
}
