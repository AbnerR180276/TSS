import React, { useState } from "react";
import { generarBarcodeJmas, generarBarcodePredial, generarBarcodeRevalidacion } from "../services/api";

const mapFn = {
  jmas: generarBarcodeJmas,
  predial: generarBarcodePredial,
  revalidacion: generarBarcodeRevalidacion,
};

export default function BarcodeGenerator() {
  const [servicio, setServicio] = useState("jmas");
  const [id, setId] = useState("");
  const [img, setImg] = useState(null);
  const [error, setError] = useState("");

  const generar = async () => {
    setError(""); setImg(null);
    try {
      const { barcode_base64 } = await mapFn[servicio](id);
      setImg(barcode_base64);
    } catch (err) {
      setError("Error: " + err.message);
    }
  };

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-lg font-bold">Generar Código de Barras</h2>

      <select value={servicio} onChange={(e)=>setServicio(e.target.value)}
        className="border p-2 rounded">
        <option value="jmas">JMAS</option>
        <option value="predial">Predial</option>
        <option value="revalidacion">Revalidación</option>
      </select>

      <input value={id} onChange={e=>setId(e.target.value)}
        placeholder="ID (ej. J123456)" className="border p-2 rounded block"/>

      <button onClick={generar} className="bg-blue-600 text-white px-4 py-2 rounded">
        Generar
      </button>

      {img && <img src={img} alt="Código" className="border mt-4" />}
      {error && <p className="text-red-600">{error}</p>}
    </div>
  );
}
