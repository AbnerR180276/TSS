import React, { useState, useEffect } from "react";
import { getJmas, postJmas } from "../services/api";
import './Forms.css';
import { Link } from 'react-router-dom';

const SERVICES = [
  { to: '/jmas-servicio', img: '/assets/jmas.png', alt: 'JMAS', label: 'Pagar JMAS' },
  { to: '/servicios?service=gasnn', img: '/assets/GN.png', alt: 'Gas Natural', label: 'Pagar Gas Natural' },
  { to: '/predial', img: '/assets/catastro.png', alt: 'Catastro', label: 'Pagar Predial' },
  { to: '/revalidacion', img: '/assets/pagos_chihuahua.png', alt: 'Pagos Chihuahua', label: 'Revalidación' }
];

export default function JmasPage() {
  const [form, setForm] = useState({
    Cuenta: "",
    direccion: "",
    giro: "Residencial", // Set default giro
    numero_medidor: "",
    nombres_apellidos: "",
  });
  const [msg, setMsg] = useState("");
  const [registros, setRegistros] = useState([]);
  const [loading, setLoading] = useState(false); // Added loading state

  // Carga inicial de registros
  useEffect(() => {
    loadRegistros();
  }, []);

  const loadRegistros = async () => {
    try {
      const data = await getJmas();
      setRegistros(data);
    } catch (err) {
      console.error("Error al cargar registros JMAS:", err);
      setMsg("Error al cargar servicios"); // Display error to user
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); // Set loading to true on submit
    setMsg("Enviando…");
    try {
      const res = await postJmas(form);
      setMsg(`✓ ${res.message || "Registro exitoso"}`);
      setForm({
        Cuenta: "",
        direccion: "",
        giro: "Residencial",
        numero_medidor: "",
        nombres_apellidos: "",
      });
      await loadRegistros(); // Ensure records are reloaded after successful post
    } catch (err) {
      setMsg("Error: " + err.message);
    } finally {
      setLoading(false); // Set loading to false after request completes
    }
  };

  return (
    <div className="jmas-page-wrapper"> {/* Use the wrapper */}
      <nav className="navbar-forms">
        <div className="navbar-left">
          <Link className="nav-item active" to="/home">Inicio</Link>
          <div className="dropdown nav-item">
            Servicios
            <ul className="dropdown-content">
              {SERVICES.map((s) => (
                <li key={s.to}><Link to={s.to}>{s.alt}</Link></li>
              ))}
            </ul>
          </div>
          <Link className="nav-item" to="/generar-codigo">Generar código</Link>
        </div>

        <div className="navbar-right">
          <div className="user-menu">
            <img
              src="/assets/user.png"
              alt="User"
              className="user-icon"
            />
            <div className="user-dropdown">
              <button className="user-btn">Iniciar Sesión</button>
              <button className="user-btn">Cerrar Sesión</button>
            </div>
          </div>
          <img src="/assets/logo-tss.png" alt="Logo" className="nav-logo" />
        </div>
      </nav>

      <h2 className="jmas-title">Servicio JMAS</h2>

      <div className="jmas-content-wrapper"> {/* New wrapper for form and list */}
        <div className="jmas-form-section"> {/* Wrapper for the form */}
          <form onSubmit={handleSubmit} className="jmas-form-layout">
            <div className="form-field-group">
              <label htmlFor="cuenta" className="form-label">Cuenta</label>
              <input
                required
                id="cuenta"
                name="Cuenta"
                value={form.Cuenta}
                onChange={e => setForm({ ...form, Cuenta: e.target.value })}
                placeholder="Cuenta"
                className="jmas-input"
              />
            </div>

            <div className="form-field-group">
              <label htmlFor="giro" className="form-label">Giro</label>
              <select
                id="giro"
                name="giro"
                value={form.giro}
                onChange={e => setForm({ ...form, giro: e.target.value })}
                className="jmas-select"
              >
                <option value="Residencial">Residencial</option>
                <option value="Comercial">Comercial</option>
              </select>
            </div>

            <div className="form-field-group">
              <label htmlFor="numero_medidor" className="form-label">No. Medidor</label>
              <input
                required
                id="numero_medidor"
                name="numero_medidor"
                value={form.numero_medidor}
                onChange={e => setForm({ ...form, numero_medidor: e.target.value })}
                placeholder="No. Medidor"
                className="jmas-input"
              />
            </div>

            <div className="form-field-group">
              <label htmlFor="direccion" className="form-label">Dirección</label>
              <input
                required
                id="direccion"
                name="direccion"
                value={form.direccion}
                onChange={e => setForm({ ...form, direccion: e.target.value })}
                placeholder="Dirección"
                className="jmas-input"
              />
            </div>

            <div className="form-field-group">
              <label htmlFor="nombres_apellidos" className="form-label">Titular</label>
              <input
                required
                id="nombres_apellidos"
                name="nombres_apellidos"
                value={form.nombres_apellidos}
                onChange={e => setForm({ ...form, nombres_apellidos: e.target.value })}
                placeholder="Titular"
                className="jmas-input"
              />
            </div>

            <button type="submit" disabled={loading} className="jmas-button jmas-submit-button">
              {loading ? 'Enviando…' : 'Registrar'}
            </button>
          </form>
          {msg && <p className="jmas-error-message">{msg}</p>}
        </div>

        <div className="jmas-services-section"> {/* Wrapper for the services list */}
          <h3 className="jmas-subtitle">Servicios Registrados</h3>
          <div className="jmas-services-list">
            {registros.map((r, i) => (
              <div key={i} className="jmas-service-item">
                <h4 className="jmas-service-account">Cuenta: {r.Cuenta}</h4>
                <p className="jmas-service-detail">Titular: {r.nombres_apellidos}</p>
                <p className="jmas-service-detail">Estado: {r.status || r.estatus}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="footer-yellow" />
    </div>
  );
}