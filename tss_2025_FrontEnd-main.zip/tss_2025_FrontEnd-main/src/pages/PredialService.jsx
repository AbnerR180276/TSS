import React, { useState, useEffect } from 'react';
import { postJson, getJson } from '../services/api';
import './Forms.css'; 
import { Link } from 'react-router-dom';

const SERVICES = [
  { to: '/jmas-servicio', img: '/assets/jmas.png', alt: 'JMAS', label: 'Pagar JMAS' },
  { to: '/servicios?service=gasnn', img: '/assets/GN.png', alt: 'Gas Natural', label: 'Pagar Gas Natural' },
  { to: '/predial', img: '/assets/catastro.png', alt: 'Catastro', label: 'Pagar Predial' },
  { to: '/revalidacion', img: '/assets/pagos_chihuahua.png', alt: 'Pagos Chihuahua', label: 'Revalidación' }
];

export default function PredialPage() {
  const [form, setForm] = useState({ nombre: '', direccion: '' });
  const [data, setData] = useState([]);
  const [loading, setLoad] = useState(false);
  const [err, setErr] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setLoad(true); setErr('');
    try {
      await postJson('/predial', form);
      setForm({ nombre: '', direccion: '' });
      await fetchAll();
    } catch (e) { setErr(e.message); }
    finally { setLoad(false); }
  };

  const fetchAll = async () => {
    try { setData(await getJson('/predial')); }
    catch { setErr('No se pudo cargar los servicios de Predial.'); }
  };

  useEffect(() => { fetchAll(); }, []);

  return (
    <div className="jmas-page-wrapper">
      <nav className="navbar-forms">
        <div className="navbar-left">
          <Link className="nav-item active" to="/home">Inicio</Link>
          <div className="dropdown nav-item">
            Servicios
            <ul className="dropdown-content">
              {SERVICES.map((s) => (
                <li key={s.to}><Link to={s.to}>{s.alt}</Link></li>
              ))}
            </ul>
          </div>
          <Link className="nav-item" to="/generar-codigo">Generar código</Link>
        </div>

        <div className="navbar-right">
          <div className="user-menu">
            <img src="/assets/user.png" alt="User" className="user-icon" />
            <div className="user-dropdown">
              <button className="user-btn">Iniciar Sesión</button>
              <button className="user-btn">Cerrar Sesión</button>
            </div>
          </div>
          <img src="/assets/logo-tss.png" alt="Logo" className="nav-logo" />
        </div>
      </nav>

      <h2 className="jmas-title">Impuesto Predial</h2>

      <div className="jmas-content-wrapper">
        <div className="jmas-form-section">
          <form onSubmit={submit} className="jmas-form-layout">
            <div className="form-field-group">
              <label htmlFor="nombre" className="form-label">Nombre</label>
              <input
                required
                id="nombre"
                placeholder="Nombre"
                value={form.nombre}
                onChange={e => setForm({ ...form, nombre: e.target.value })}
                className="jmas-input"
              />
            </div>
            <div className="form-field-group">
              <label htmlFor="direccion" className="form-label">Dirección</label>
              <input
                required
                id="direccion"
                placeholder="Dirección"
                value={form.direccion}
                onChange={e => setForm({ ...form, direccion: e.target.value })}
                className="jmas-input"
              />
            </div>
            <button type="submit" disabled={loading} className="jmas-button jmas-submit-button">
              {loading ? 'Enviando…' : 'Registrar consulta'}
            </button>
          </form>
          {err && <p className="jmas-error-message">{err}</p>}
        </div>

        <div className="jmas-services-section">
          <h3 className="jmas-subtitle">Consultas de Predial Registradas</h3>
          <div className="jmas-services-list">
            {data.length > 0 ? (
              data.map((r) => (
                <div key={r.clave} className="jmas-service-item">
                  <h4 className="jmas-service-account">Clave: {r.clave}</h4>
                  <p className="jmas-service-detail">Nombre: {r.nombre}</p>
                  <p className="jmas-service-detail">Estatus: {r.estatus}</p>
                  <p className="jmas-service-detail">Total a pagar: ${r.total_pagar?.toFixed(2) || 'N/A'}</p>
                </div>
              ))
            ) : (
              <p className="jmas-error-message">No hay registros de predial.</p>
            )}
          </div>
        </div>
      </div>

      <div className="footer-yellow" />
    </div>
  );
}
